package DBMS;

import java.io.Serializable;
import java.util.ArrayList;

public class Page implements Serializable
{
	    public ArrayList<String[]> records;

	    public Page() {
	        records = new ArrayList<>();
	    }

	    public boolean isFull() {
	        if (records.size() < DBApp.dataPageSize)
	            return false;
	        else
	            return true;
	    }


	    public void addRecord(String[] record) {
	        records.add(record);
	    }

		public String[] getRecord(int index) {
			if (index >= 0 && index < records.size()) {
				return records.get(index);
			}
			return null;
		}
}


