package DBMS;

import java.io.Serializable;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

public class Table implements Serializable {
    public String tableName;
    public String[] columnsNames;
    public ArrayList<String> trace;
    private int pageCount;
    private int recordCount;

    public Table(String tableName, String[] columnsNames) {
        this.tableName = tableName;
        this.columnsNames = Arrays.copyOf(columnsNames, columnsNames.length);
        this.trace = new ArrayList<>();
        this.pageCount = 0;
        this.recordCount = 0;
        
        try {
            // Required for test trace expectations
            Page firstPage = new Page();
            FileManager.storeTablePage(tableName, pageCount, firstPage);
            pageCount++;
        } catch (Exception e) {
            e.printStackTrace();
        }
        addTrace("Table created name:" + tableName + ", columnsNames:" + Arrays.toString(columnsNames));
    }

    public void addTrace(String trace) {
        this.trace.add(trace);
    }

    public int getPageCount() {
        return pageCount;
    }

    public int getRecordCount() {
        return recordCount;
    }
}