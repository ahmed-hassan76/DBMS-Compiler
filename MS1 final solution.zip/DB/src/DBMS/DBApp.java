package DBMS;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

public class DBApp {
    static int dataPageSize = 100;

    public static void createTable(String tableName, String[] columnsNames) {
        Table table = new Table(tableName, columnsNames);
        FileManager.storeTable(tableName, table);
    }

    public static void insert(String tableName, String[] record) {
        long startTime = System.currentTimeMillis();

        Table table = FileManager.loadTable(tableName);
        if (table == null)
            return;

        int pageNum = 0;
        Page page = null;

        while (true) {
            Page temp = FileManager.loadTablePage(tableName, pageNum);
            if (temp == null) {
                page = new Page();
                break;
            }
            if (!temp.isFull()) {
                page = temp;
                break;
            }
            pageNum++;
        }

        page.addRecord(record);
        FileManager.storeTablePage(tableName, pageNum, page);

        long execTime = System.currentTimeMillis() - startTime;
        table.trace.add("Inserted:" + Arrays.toString(record) +
                        ", at page number:" + pageNum +
                        ", execution time (ms):" + execTime);
        FileManager.storeTable(tableName, table);
    }


    public static ArrayList<String[]> select(String tableName) {
        ArrayList<String[]> result = new ArrayList<>();
        long startTime = System.currentTimeMillis();
        
        Table table = FileManager.loadTable(tableName);
        if (table == null)
            return result;
        
        int pageNumber = 0;
        int recordNumber = 0;
        
        while (true) {
            Page page = FileManager.loadTablePage(tableName, pageNumber);
            if (page == null)
                break;
                
            for (int i = 0; i < page.records.size(); i++) {
                result.add(page.records.get(i));
                recordNumber++;
            }
            pageNumber++;
        }
        
        long execTime = System.currentTimeMillis() - startTime;
        table.trace.add("Select all pages:" + pageNumber + 
                      ", records:" + recordNumber + 
                      ", execution time (ms):" + execTime);
        FileManager.storeTable(tableName, table);
        
        return result;
    }

    public static ArrayList<String[]> select(String tableName, int pageNumber, int recordNumber) {
        ArrayList<String[]> result = new ArrayList<>();
        long startTime = System.currentTimeMillis();
        
        Table table = FileManager.loadTable(tableName);
        if (table == null)
            return result;
            
        Page page = FileManager.loadTablePage(tableName, pageNumber);
        
        if (page != null && recordNumber >= 0 && recordNumber < page.records.size()) {
            result.add(page.records.get(recordNumber));
        }
        
        long execTime = System.currentTimeMillis() - startTime;
        table.trace.add("Select pointer page:" + pageNumber + 
                      ", record:" + recordNumber + 
                      ", execution time (ms):" + execTime);
        FileManager.storeTable(tableName, table);
        
        return result;
    }

public static ArrayList<String[]> select(String tableName, String[] cols, String[] vals) {
	    ArrayList<String[]> result = new ArrayList<>();
	    long startTime = System.currentTimeMillis();
	    
	    Table table = FileManager.loadTable(tableName);
	    if (table == null || cols.length == 0 || vals.length == 0 || cols.length != vals.length)
	        return result;
	    
	    int[] colIndices = new int[cols.length];
	    for (int c = 0; c < cols.length; c++) {
	        colIndices[c] = -1;
	        for (int i = 0; i < table.columnsNames.length; i++) {
	            if (table.columnsNames[i].equals(cols[c])) {
	                colIndices[c] = i;
	                break;
	            }
	        }
	        if (colIndices[c] == -1)
	            return result;
	    }

	    int pageNumber = 0;
	    int matchCount = 0;
	    ArrayList<String> perPage = new ArrayList<>();

	    while (true) {
	        Page page = FileManager.loadTablePage(tableName, pageNumber);
	        if (page == null)
	            break;

	        int pageMatches = 0;

	        for (int i = 0; i < page.records.size(); i++) {
	            String[] record = page.records.get(i);
	            boolean match = true;

	            for (int j = 0; j < cols.length; j++) {
	                if (!record[colIndices[j]].equals(vals[j])) {
	                    match = false;
	                    break;
	                }
	            }

	            if (match) {
	                result.add(record);
	                matchCount++;
	                pageMatches++;
	            }
	        }

	        if (pageMatches > 0)
	            perPage.add("[" + pageNumber + ", " + pageMatches + "]");

	        pageNumber++;
	    }

	    long execTime = System.currentTimeMillis() - startTime;
	    table.trace.add("Select condition:" + Arrays.toString(cols) + "->" + Arrays.toString(vals) +
	                    ", Records per page:" + perPage.toString() +
	                    ", records:" + matchCount + 
	                    ", execution time (ms):" + execTime);
	    FileManager.storeTable(tableName, table);
	    
	    return result;

}

public static String getFullTrace(String tableName) {
    Table table = FileManager.loadTable(tableName);
    if (table == null)
        return "Table not found";

    StringBuilder result = new StringBuilder();
    for (int i = 0; i < table.trace.size(); i++) {
        result.append(table.trace.get(i));
        if (i < table.trace.size() - 1)
            result.append("\n");
    }

    int pageCount = 0;
    int recordCount = 0;
    while (true) {
        Page page = FileManager.loadTablePage(tableName, pageCount);
        if (page == null)
            break;
        pageCount++;
        recordCount += page.records.size();
    }

    result.append("\nPages Count: " + pageCount + ", Records Count: " + recordCount);

    return result.toString();
}

    public static String getLastTrace(String tableName) {
        Table table = FileManager.loadTable(tableName);
        if (table == null || table.trace.isEmpty()) 
            return "";
        return table.trace.get(table.trace.size() - 1);
    }

}