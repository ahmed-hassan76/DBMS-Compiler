package DBMS;

import java.io.Serializable;
import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;

public class BitmapIndex implements Serializable {
    private static final long serialVersionUID = 1L;
    private String tableName;
    private String colName;
    private int size;
    private Map<String, String> bitmaps;

    public BitmapIndex(String tableName, String colName, int size) {
        this.tableName = tableName;
        this.colName = colName;
        this.size = size;
        this.bitmaps = new HashMap<>();
    }

    // populate all entries in the map at once
    public void setBitmaps(Map<String, String> bitmaps) {
        this.bitmaps = bitmaps;
    }

    // retrieve bitstring for a given value, or zeros if not present
    public String getBits(String value) {
        String bits = bitmaps.get(value);
        if (bits != null) {
            return bits;
        }
        // return zero string if value not indexed
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < size; i++) {
            sb.append('0');
        }
        return sb.toString();
    }

    /**
     * Extend this bitmap index for a newly inserted record value.
     */
    public void extend(String value) {
        // increase total size
        this.size++;
        // append '0' to all existing bitstrings
        for (Map.Entry<String, String> e : bitmaps.entrySet()) {
            e.setValue(e.getValue() + '0');
        }
        // set '1' for this value at new position
        String bits = bitmaps.get(value);
        if (bits != null) {
            // replace trailing '0' with '1'
            bits = bits.substring(0, bits.length() - 1) + '1';
        } else {
            // new value: a string of zeros ending with '1'
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < size - 1; i++) sb.append('0');
            sb.append('1');
            bits = sb.toString();
        }
        bitmaps.put(value, bits);
    }

    // Returns a string representing the creation trace for this bitmap index
    public String getFullTrace() {
        return "BitmapIndex created for table: " + tableName + ", column: " + colName + ", size: " + size;
    }
}

// No changes needed for BitmapIndex for trace/history. Index tracking and trace is now handled in Table and DBApp.
// Ensure BitmapIndex remains focused on bitmap storage and retrieval only.
