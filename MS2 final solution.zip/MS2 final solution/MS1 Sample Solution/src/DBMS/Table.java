package DBMS;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;

public class Table implements Serializable
{
	private String name;
	private String[] columnsNames;
	private int pageCount;
	private int recordsCount;
	private ArrayList<String> trace;
	private ArrayList<String> indexedColumns;
	// Add a field to hold bitmap indexes for this table
    private transient Map<String, BitmapIndex> bitmapIndexes;

		public Table(String name, String[] columnsNames) 
	{
		super();
		this.name = name;
		this.columnsNames = columnsNames;
		this.trace = new ArrayList<String>();
		this.indexedColumns = new ArrayList<>();
		// Initial table creation trace
		this.trace.add("Table created name:" + name + ", columnsNames:"
				+ Arrays.toString(columnsNames));
		// No longer adding indexed columns trace
		// It will be dynamically generated in getFullTrace
	}


	@Override
	public String toString() 
	{
		return "Table [name=" + name + ", columnsNames="
				+ Arrays.toString(columnsNames) + ", pageCount=" + pageCount
				+ ", recordsCount=" + recordsCount + "]";
	}
	
	public void insert(String []record)
	{
		long startTime = System.currentTimeMillis();
		Page current = FileManager.loadTablePage(this.name, pageCount-1);
		if(current==null||!current.insert(record))
		{
			current = new Page();
			current.insert(record);
			pageCount++;
		}
		FileManager.storeTablePage(this.name, pageCount-1, current);
		recordsCount++;
		long stopTime = System.currentTimeMillis();
		this.trace.add("Inserted:"+ Arrays.toString(record)+", at page number:"+(pageCount-1)
				+", execution time (mil):"+(stopTime - startTime));
	}
	
	public String[] fixCond(String[] cols, String[] vals)
	{
		String[] res = new String[columnsNames.length];
		for(int i=0;i<res.length;i++)
		{
			for(int j=0;j<cols.length;j++)
			{
				if(columnsNames[i].equals(cols[j]))
				{
					res[i]=vals[j];
				}
			}
		}
		return res;
	}
	
	public ArrayList<String []> select(String[] cols, String[] vals)
	{
		String[] cond = fixCond(cols, vals);
		String tracer ="Select condition:"+Arrays.toString(cols)+"->"+Arrays.toString(vals);
		ArrayList<ArrayList<Integer>> pagesResCount = new ArrayList<ArrayList<Integer>>();
		ArrayList<String []> res = new ArrayList<String []>();
		long startTime = System.currentTimeMillis();
		for(int i=0;i<pageCount;i++)
		{
			Page p = FileManager.loadTablePage(this.name, i);
			ArrayList<String []> pRes = p.select(cond);
			if(pRes.size()>0)
			{
				ArrayList<Integer> pr = new ArrayList<Integer>();
				pr.add(i);
				pr.add(pRes.size());
				pagesResCount.add(pr);
				res.addAll(pRes);
			}
		}
		long stopTime = System.currentTimeMillis();
		tracer +=", Records per page:" + pagesResCount+", records:"+res.size()
				+", execution time (mil):"+(stopTime - startTime);
		this.trace.add(tracer);
		return res;
	}
	
	public ArrayList<String []> select(int pageNumber, int recordNumber)
	{
		String tracer ="Select pointer page:"+pageNumber+", record:"+recordNumber;
		ArrayList<String []> res = new ArrayList<String []>();
		long startTime = System.currentTimeMillis();
		Page p = FileManager.loadTablePage(this.name, pageNumber);
		ArrayList<String []> pRes = p.select(recordNumber);
		if(pRes.size()>0)
		{
			res.addAll(pRes);
		}
		long stopTime = System.currentTimeMillis();
		tracer+=", total output count:"+res.size()
				+", execution time (mil):"+(stopTime - startTime);
		this.trace.add(tracer);
		return res;
	}
	
	
	public ArrayList<String []> select()
	{
		ArrayList<String []> res = new ArrayList<String []>();
		long startTime = System.currentTimeMillis();
		for(int i=0;i<pageCount;i++)
		{
			Page p = FileManager.loadTablePage(this.name, i);
			res.addAll(p.select());
		}
		long stopTime = System.currentTimeMillis();
		this.trace.add("Select all pages:" + pageCount+", records:"+recordsCount
				+", execution time (mil):"+(stopTime - startTime));
		return res;
	}
	
		public void addIndexColumn(String colName) {
		if (!indexedColumns.contains(colName)) {
			indexedColumns.add(colName);
			// Sort the indexed columns to match test expectations
			java.util.Collections.sort(indexedColumns);
			// No longer add trace entries for indexed columns
			// The indexed columns will be dynamically generated in getFullTrace
		}
	}
	
	
	public ArrayList<String> getIndexedColumns() {
	    return new ArrayList<>(indexedColumns);
	}
	
	
	
	
	
	public String getFullTrace() 
    {
        StringBuilder sb = new StringBuilder();
        // Add all trace entries except any Indexed Columns entries
        for (String entry : this.trace) {
            if (!entry.startsWith("Indexed Columns:")) {
                sb.append(entry).append("\n");
            }
        }
        // Defensive: ensure bitmapIndexes is not null
        if (bitmapIndexes == null) {
            bitmapIndexes = new java.util.HashMap<>();
        }
        // Add bitmap index creation traces for all indexed columns (in order)
        for (String col : indexedColumns) {
            BitmapIndex idx = bitmapIndexes.get(col);
            if (idx != null) {
                sb.append(idx.getFullTrace()).append("\n");
            }
        }
        // Always append the current indexed columns as the last line, using Arrays.toString for correct format
        sb.append("Indexed Columns: ").append(Arrays.toString(indexedColumns.toArray(new String[0])));
        return sb.toString();
    }
		public String getLastTrace() 
	{
		if (this.trace.isEmpty()) {
			return "";
		}
		return this.trace.get(this.trace.size()-1);
	}
    public String[] getColumnsNames() {
        return this.columnsNames;
    }    public int getRecordsCount() {
        return this.recordsCount;
    }    
    
    public int getPageCount() {
        return this.pageCount;
    }
    
    /**
     * Log a trace entry for indexed columns list.
     */    public void logIndexedColumnsTrace(java.util.List<String> cols) {
        String colsStr = Arrays.toString(cols.toArray(new String[0]));
        // Always append a new entry for each index creation (do not remove previous)
        this.trace.add("Indexed Columns: " + colsStr);
    }
    /**
     * Log a custom trace entry (for selectIndex, etc).
     */
    public void logTrace(String msg) {
        this.trace.add(msg);
    }
    /**
     * Recover missing records to their original pages and positions.
     * Returns the list of affected page numbers.
     */    public ArrayList<Integer> recoverRecords(ArrayList<String[]> records, int[] pageNumbers, int[] recordIndices) {        ArrayList<Integer> affectedPages = new ArrayList<>();
        if (records.isEmpty()) {
            // Even with empty records, we need to add the trace message
            this.trace.add("Recovering 0 records in pages: []");
            return affectedPages;
        }
        
        for (int i = 0; i < records.size(); i++) {
            int pageNum = pageNumbers[i];
            int recIdx = recordIndices[i];
            Page p = FileManager.loadTablePage(this.name, pageNum);
            if (p == null) {
                p = new Page();
                if (pageNum >= pageCount) {
                    pageCount = pageNum + 1;
                }
            }
            p.insertAt(records.get(i), recIdx);
            FileManager.storeTablePage(this.name, pageNum, p);
            if (!affectedPages.contains(pageNum)) {
                affectedPages.add(pageNum);
            }
            recordsCount++;
        }
        
        // Add trace message for record recovery as the last thing we do
        this.trace.add("Recovering " + records.size() + " records in pages: " + affectedPages);
        return affectedPages;
    }
    // Add a method to register a bitmap index for a column
    public void addBitmapIndex(String colName, BitmapIndex idx) {
        if (bitmapIndexes == null) {
            bitmapIndexes = new java.util.HashMap<>();
        }
        bitmapIndexes.put(colName, idx);
    }

}
